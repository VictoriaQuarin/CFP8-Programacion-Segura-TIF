DROP DATABASE IF EXISTS progsegura_tif;
CREATE DATABASE progsegura_tif; 
USE progsegura_tif;

--
INSERT INTO users (username, password, enabled, account_not_expired, account_not_locked, credential_not_expired)
VALUES
('centro8', '$2a$10$RsAhLkY2e49vEhhujCDYz.6PrJ5y3RS8u6dDCoa3vIiRVcUYSpL32', 1, 1, 1, 1);

INSERT INTO roles (role) VALUES ('ADMIN');

-- Asociación de Usuario al Rol
INSERT INTO user_roles (user_id, role_id)
VALUES (
	(SELECT id FROM users WHERE username = 'centro8'),
    (SELECT id FROM roles WHERE role = 'ADMIN')
);
--

-- Asociación de Permisos READ y CREATE, al Rol ADMIN
SELECT id FROM roles WHERE role = 'ADMIN';
SELECT id FROM permissions WHERE permission_name = 'READ';
SELECT id FROM permissions WHERE permission_name = 'UPDATE';
SELECT id FROM permissions WHERE permission_name = 'CREATE';
SELECT id FROM permissions WHERE permission_name = 'DELETE';

-- Inserción de las Asociaciones en la Tabla de Enlace
INSERT INTO roles_permissions (role_id, permission_id) VALUES (1, 1); -- ROL ADMIN - PERMISSION READ
INSERT INTO roles_permissions (role_id, permission_id) VALUES (1, 2); -- ROL ADMIN - PERMISSION UPDATE
INSERT INTO roles_permissions (role_id, permission_id) VALUES (1, 3); -- ROL ADMIN - PERMISSION CREATE
INSERT INTO roles_permissions (role_id, permission_id) VALUES (1, 4); -- ROL ADMIN - PERMISSION DELETE

-- Verificación de la Asociación
SELECT * FROM roles_permissions WHERE role_id = 1;


-- Verificar usuarios a borrar
SELECT * FROM users WHERE username IN ('USER_PRUEBA1', 'USER_PRUEBA2_UPDATED');

-- Verificar roles a borrar
SELECT * FROM roles WHERE id IN (2, 3);

-- Verificar roles asignados a esos usuarios
SELECT * FROM user_roles WHERE user_id IN (
    SELECT id FROM users WHERE username IN ('USER_PRUEBA1', 'USER_PRUEBA2_UPDATED')
);

-- Verificar permisos asignados a esos roles
SELECT * FROM roles_permissions WHERE role_id IN (2, 3);