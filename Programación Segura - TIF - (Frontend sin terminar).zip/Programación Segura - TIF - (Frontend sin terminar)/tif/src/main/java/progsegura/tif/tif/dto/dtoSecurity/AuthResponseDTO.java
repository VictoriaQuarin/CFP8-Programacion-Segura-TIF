package progsegura.tif.tif.dto.dtoSecurity;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/*Cuando una clase se declara como un registro, el compilador de Java genera automáticamente
ciertos métodos como el constructor, los métodos equals(), hashCode() y toString(),
basados en los componentes de datos declarados en la clase.*/
/*Este DTO es lo que vas a devolver cuando alguien se loguea correctamente.*/
@JsonPropertyOrder({"username", "message", "jwt", "status"})
public record AuthResponseDTO(
    String username,
    String message,
    String jwt,
    boolean status) {
    }