package progsegura.tif.tif.dto.dtoGestionIncidentes;

import java.util.List;

public record SecurityReporterDTO(
    Long id,
    String nombre,
    String apellido,
    String areaTrabajo,
    List<Long> incidentesIds) {
    }