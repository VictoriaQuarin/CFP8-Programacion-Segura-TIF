package progsegura.tif.tif.controller.controllerSecurity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "Bienvenido a la aplicación segura";
    }

    @GetMapping("/holaseg")
    public String holaSeg() {
        return "¡Hola con Seguridad!";
    }

    @GetMapping("/holanoseg")
    public String holaNoSeg() {
        return "¡Hola sin Seguridad!";
    }
}