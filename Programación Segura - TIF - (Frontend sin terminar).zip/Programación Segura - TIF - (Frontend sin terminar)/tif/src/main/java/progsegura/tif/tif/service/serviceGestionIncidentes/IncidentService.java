package progsegura.tif.tif.service.serviceGestionIncidentes;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import progsegura.tif.tif.entity.Incident;
import progsegura.tif.tif.repository.repositoryGestionIncidentes.IIncidentRepository;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class IncidentService implements IIncidentService {

    @Autowired
    private IIncidentRepository incidentRepository;

    @Override
    public List<Incident> findAll() {
        return incidentRepository.findAll();
    }

    @Override
    public Optional<Incident> findById(Long id) {
        return incidentRepository.findById(id);
    }

    @Override
    public Incident save(Incident incident) {
        return incidentRepository.save(incident);
    }

    @Override
    public void deleteById(Long id) {
        incidentRepository.deleteById(id);
    }

    @Override
    public Incident update(Incident incident) {
        return incidentRepository.save(incident);
    }
}