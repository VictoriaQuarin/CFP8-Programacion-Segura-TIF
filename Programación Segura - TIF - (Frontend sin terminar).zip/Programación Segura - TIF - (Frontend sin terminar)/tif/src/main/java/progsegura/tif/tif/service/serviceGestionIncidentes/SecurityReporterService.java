package progsegura.tif.tif.service.serviceGestionIncidentes;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import progsegura.tif.tif.entity.SecurityReporter;
import progsegura.tif.tif.repository.repositoryGestionIncidentes.ISecurityReporterRepository;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SecurityReporterService implements ISecurityReporterService {

    @Autowired
    private ISecurityReporterRepository securityReporterRepository;

    @Override
    public List<SecurityReporter> findAll() {
        return securityReporterRepository.findAll();
    }

    @Override
    public Optional<SecurityReporter> findById(Long id) {
        return securityReporterRepository.findById(id);
    }

    @Override
    public SecurityReporter save(SecurityReporter sr) {
        return securityReporterRepository.save(sr);
    }

    @Override
    public void deleteById(Long id) {
        securityReporterRepository.deleteById(id);
    }

    @Override
    public SecurityReporter update(SecurityReporter sr) {
        return securityReporterRepository.save(sr);
    }
}