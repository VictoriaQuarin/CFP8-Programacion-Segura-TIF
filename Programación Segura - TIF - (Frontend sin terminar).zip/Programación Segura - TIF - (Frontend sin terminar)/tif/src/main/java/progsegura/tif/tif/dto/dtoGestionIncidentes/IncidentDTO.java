package progsegura.tif.tif.dto.dtoGestionIncidentes;

import java.time.LocalDate;

public record IncidentDTO(
    Long id,
    String tipoIncident,
    String estadoIncident,
    LocalDate fechaReporte,
    Long reporterId) {
    }
