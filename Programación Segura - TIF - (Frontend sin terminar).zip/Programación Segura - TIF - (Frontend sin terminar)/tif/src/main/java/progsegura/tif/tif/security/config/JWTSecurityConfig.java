package progsegura.tif.tif.security.config;

import progsegura.tif.tif.security.config.filter.JwtTokenValidator;
import progsegura.tif.tif.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.core.annotation.Order;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity

public class JWTSecurityConfig {

    @Autowired
    private JwtUtils jwtUtils;

    @Bean
    @Order(1)

    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .securityMatcher("/api/**")
                .csrf(csrf -> csrf.disable())
                .httpBasic(Customizer.withDefaults())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // Permite LOGIN sin token JWT
                        .requestMatchers("/api/auth/login").permitAll()

                        // Solo ADMIN puede hacer DELETE de incidentes y reporteros
                        .requestMatchers(HttpMethod.DELETE, "/api/incidents/**").hasAuthority("ROLE_ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/reporters/**").hasAuthority("ROLE_ADMIN")

                        // ADMIN y SECURITY_REPORTER pueden crear y actualizar incidentes
                        .requestMatchers(HttpMethod.POST, "/api/incidents/**").hasAnyAuthority("ROLE_ADMIN", "ROLE_SECURITY_REPORTER")
                        .requestMatchers(HttpMethod.PUT, "/api/incidents/**").hasAnyAuthority("ROLE_ADMIN", "ROLE_SECURITY_REPORTER")
                        .requestMatchers(HttpMethod.DELETE, "/api/users/**").hasAuthority("ROLE_ADMIN")

                        // ADMIN puede crear y actualizar reporteros
                        .requestMatchers(HttpMethod.POST, "/api/reporters/**").hasAuthority("ROLE_ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/reporters/**").hasAuthority("ROLE_ADMIN")

                        // Todos los roles autenticados pueden leer
                        .requestMatchers(HttpMethod.GET, "/api/**").authenticated()

                        // Todo lo demás también necesita autenticación
                        .anyRequest().authenticated()
                )
                .addFilterBefore(new JwtTokenValidator(jwtUtils), BasicAuthenticationFilter.class)
                .build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }

    @Bean
    public AuthenticationProvider authenticationProvider(UserDetailsService userDetailsService) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}