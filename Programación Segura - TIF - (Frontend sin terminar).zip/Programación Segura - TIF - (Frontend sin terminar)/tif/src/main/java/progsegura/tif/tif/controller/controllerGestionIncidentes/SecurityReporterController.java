package progsegura.tif.tif.controller.controllerGestionIncidentes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import progsegura.tif.tif.dto.dtoGestionIncidentes.SecurityReporterDTO;
import progsegura.tif.tif.entity.SecurityReporter;
import progsegura.tif.tif.entity.Incident;
import progsegura.tif.tif.service.serviceGestionIncidentes.SecurityReporterService;

@RestController
@RequestMapping("/api/reporters")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SecurityReporterController {

    @Autowired
    private SecurityReporterService securityReporterService;

    private SecurityReporterDTO mapToDTO(SecurityReporter sr) {
        List<Long> incidentIds = sr.getIncidents() != null
            ? sr.getIncidents().stream().map(Incident::getId).collect(Collectors.toList())
            : List.of();

        return new SecurityReporterDTO(
            sr.getId(),
            sr.getNombre(),
            sr.getApellido(),
            sr.getAreaTrabajo(),
            incidentIds
        );
    }

    private SecurityReporter mapToEntity(SecurityReporterDTO dto) {
        SecurityReporter sr = new SecurityReporter();
        sr.setId(dto.id());
        sr.setNombre(dto.nombre());
        sr.setApellido(dto.apellido());
        sr.setAreaTrabajo(dto.areaTrabajo());
        // No cargamos los incidentes en el set aquí para evitar loops o carga innecesaria
        return sr;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER', 'ANALYST')")
    public ResponseEntity<List<SecurityReporterDTO>> getAllReporters() {
        List<SecurityReporter> reporters = securityReporterService.findAll();
        List<SecurityReporterDTO> dtos = reporters.stream().map(this::mapToDTO).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER', 'ANALYST')")
    public ResponseEntity<SecurityReporterDTO> getReporter(@PathVariable Long id) {
        return securityReporterService.findById(id)
                .map(this::mapToDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER')")
    public ResponseEntity<?> createReporter(@RequestBody SecurityReporterDTO dto) {
        SecurityReporter sr = mapToEntity(dto);
        securityReporterService.save(sr);
        return ResponseEntity.ok("Reporter creado");
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER')")
    public ResponseEntity<?> updateReporter(@PathVariable Long id, @RequestBody SecurityReporterDTO dto) {
        SecurityReporter sr = mapToEntity(dto);
        sr.setId(id);
        securityReporterService.update(sr);
        return ResponseEntity.ok("Reporter actualizado");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteReporter(@PathVariable Long id) {
        securityReporterService.deleteById(id);
        return ResponseEntity.ok("Reporter eliminado");
    }
}