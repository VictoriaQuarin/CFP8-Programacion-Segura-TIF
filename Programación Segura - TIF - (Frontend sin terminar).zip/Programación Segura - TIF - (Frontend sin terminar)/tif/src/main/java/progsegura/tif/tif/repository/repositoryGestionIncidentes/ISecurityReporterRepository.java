package progsegura.tif.tif.repository.repositoryGestionIncidentes;

import progsegura.tif.tif.entity.SecurityReporter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ISecurityReporterRepository extends JpaRepository<SecurityReporter, Long> {
}