package progsegura.tif.tif.controller.controllerGestionIncidentes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import progsegura.tif.tif.dto.dtoGestionIncidentes.IncidentDTO;
import progsegura.tif.tif.entity.Incident;
import progsegura.tif.tif.entity.SecurityReporter;
import progsegura.tif.tif.service.serviceGestionIncidentes.IncidentService;
import progsegura.tif.tif.service.serviceGestionIncidentes.SecurityReporterService;

@RestController
@RequestMapping("/api/incidents")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class IncidentController {

    @Autowired
    private IncidentService incidentService;

    @Autowired
    private SecurityReporterService securityReporterService;


private IncidentDTO mapToDTO(Incident incident) {
    return new IncidentDTO(
        incident.getId(),
        incident.getTipo(),
        incident.getEstado(),
        incident.getFechaReporte(),
        incident.getReporter() != null ? incident.getReporter().getId() : null
    );
}

private Incident mapToEntity(IncidentDTO dto) {
    Incident incident = new Incident();
    incident.setId(dto.id());
    incident.setTipo(dto.tipoIncident());
    incident.setEstado(dto.estadoIncident());
    incident.setFechaReporte(dto.fechaReporte());
    if (dto.reporterId() != null) {
        SecurityReporter sr = securityReporterService.findById(dto.reporterId()).orElse(null);
        incident.setReporter(sr);
    } else {
        incident.setReporter(null);
    }
    return incident;
}

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER', 'ANALYST')")
    public ResponseEntity<List<IncidentDTO>> getAllIncidents() {
        List<Incident> incidents = incidentService.findAll();
        List<IncidentDTO> dtos = incidents.stream().map(this::mapToDTO).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER', 'ANALYST')")
    public ResponseEntity<IncidentDTO> getIncident(@PathVariable Long id) {
        return incidentService.findById(id)
                .map(this::mapToDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER')")
    public ResponseEntity<?> createIncident(@RequestBody IncidentDTO dto) {
        Incident incident = mapToEntity(dto);
        if (incident.getReporter() == null || incident.getReporter().getId() == null) {
            return ResponseEntity.badRequest().body("Debe indicar un SecurityReporter válido.");
        }
        incidentService.save(incident);
        return ResponseEntity.ok("Incidente creado correctamente");
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'SECURITY_REPORTER')")
    public ResponseEntity<?> updateIncident(@PathVariable Long id, @RequestBody IncidentDTO dto) {
        Incident incident = mapToEntity(dto);
        incident.setId(id);
        incidentService.update(incident);
        return ResponseEntity.ok("Incidente actualizado");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteIncident(@PathVariable Long id) {
        incidentService.deleteById(id);
        return ResponseEntity.ok("Incidente eliminado");
    }
}