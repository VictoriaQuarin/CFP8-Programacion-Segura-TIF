// Guarda el JWT y redirige según el rol del usuario.

// Hace el POST a /auth/login enviando username y password.
// Guarda el JWT que responde el backend en localStorage.
// Luego hace un GET a /api/user/me incluyendo el JWT en el Authorization header.
// Interpreta los roles recibidos y redirige según el rol del usuario a la vista correspondiente.

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("login-form");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
      });

      if (!response.ok) {
        alert("Error de login");
        console.error("Respuesta error:", await response.text());
        return;
      }

      const data = await response.json();
      console.log("Respuesta login:", data);

      const token = data.jwt;

      if (!token) {
        alert("Token no recibido");
        return;
      }

      localStorage.setItem("jwt", token);

      const userRes = await fetch("/api/user/me", {
        headers: {
          Authorization: "Bearer " + token
        }
      });

      if (!userRes.ok) {
        alert("No se pudo obtener información del usuario");
        console.error("Error user/me:", await userRes.text());
        return;
      }

      const user = await userRes.json();
      console.log("Datos usuario:", user);

      const roles = user.roles || [];
      const roleNames = roles.map(r => typeof r === "string" ? r : r.name);

      if (roleNames.includes("ADMIN")) {
        window.location.href = "/admin.html";
      } else if (roleNames.includes("ANALYST")) {
        window.location.href = "/analyst.html";
      } else if (roleNames.includes("SECURITYREPORTER")) {
        window.location.href = "/reporter.html";
      } else {
        alert("Rol no reconocido");
      }

    } catch (err) {
      console.error("Error en login:", err);
      alert("Error inesperado en login");
    }
  });
});
