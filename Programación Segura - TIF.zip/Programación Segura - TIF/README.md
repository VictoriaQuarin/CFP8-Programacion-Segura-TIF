#### CFP 8 - ESPECIALIZACIÓN EN PROGRAMACIÓN SEGURA

#### MÓDULO: PROGRAMACIÓN SEGURA

#### PROYECTO FINAL INTEGRADOR - DESARROLLO DE API

#### PROFESOR A CARGO: Prof. Jorge Sánchez

##### ALUMNA: Victoria Escobar Quarin


**RESTRINCCIONES LÓGICAS DE NEGOCIO**

**MODELO DE NEGOCIO ELEGIDO: Sistema de Gestión de Incidentes de Seguridad Informática**


**Descripción General del Proyecto**

El Sistema tiene como objetivo gestionar incidentes de seguridad reportados en un banco. Los usuarios que están habilitados a utilizar el software pueden realizar reportes, análisis, modificaciones y administrar los incidentes de acuerdo a los roles y permisos asignados y establecidos en el código.


**Roles del Sistema**

**Administrador (ADMIN)**

Usuario con permisos totales sobre el Sistema. Es capaz de gestionar usuarios, roles, permisos e incidentes.

**Analyst (ANALYST)**

Usuario encargado de investigar incidentes. Está habilitado para crear, leer y actualizar incidentes.

**Security Reporter (SECURITY_REPORTER)**

Usuario con habilitación únicamente para el reporte de incidentes. Sólo puede leer incidentes existentes.


**Permisos del Sistema**

ADMIN - CRUD completo; eso incluye CREATE, READ, UPDATE y DELETE.

ANALYST - Habilitado para CREATE, READ y UPDATE.

SECURITY_REPORTER - Únicamente tiene permiso READ.


**Usuarios del Sistema**

Rol ADMIN - Usuario ADMIN.

Rol ANALYST - Usuario Analyst1

Rol SECURITY_REPORTER - Usuario Security_Reporter1


**Diagrama DER - Relaciones entre Entidades**

El mínimo requerido para el Proyecto en cuanto a relaciones, debe darse entre dos entidades de usuario.

Esto se llevará a cabo mediante las siguientes relaciones:

Un Security Reporter puede reportar como mínimo/máximo un Incidente. Mientras que un Incidente puede ser reportado como mínimo por un Security_Reporter y como máximo por muchos Security_Reporters.

![1752819296574](image/README/1752819296574.jpg)

**Tipos de Autenticaciones en el TIF**

1. **JWT para `/api/**`**

* En `JWTSecurityConfig` está configurado lo siguiente:
  * Los endpoints que empiezan con `/api/` usan un filtro JWT (`JwtTokenValidator`) para validar el token enviado en el header `Authorization: Bearer <token>`.
  * No se utilizan sesiones, porque se define `SessionCreationPolicy.STATELESS` para esos endpoints.
  * El login JWT está expuesto en `/auth/login` y devuelve un token JWT que se crea en `JwtUtils` y se manda al cliente (probablemente en JSON).

2. **Sesión con Cookies para el resto (`/**`)**

* En `OAuthSecurityConfig`  está configuración para la web tradicional con formulario y OAuth2:
  * La configuración para todos los endpoints que no son `/api/**` usan `formLogin()` y `oauth2Login()`.
  * El login es mediante sesión, con cookies tipo `JSESSIONID` creadas automáticamente por Spring Security.
  * El login en `/login` y los endpoints relacionados están abiertos (`permitAll()`).
  * Al iniciar sesión con formulario o con OAuth2, Spring maneja la sesión, y te mantiene logueado con la cookie de sesión.

**Flujo JWT y FrontEnd**

1. HTML con formulario de login.
2. JS toma usuario y contraseña → hace `POST` a `/auth/login`.
3. Backend responde con JWT y tal vez más info (nombre, rol).
4. JS guarda el JWT en `localStorage`.
5. Luego, JS hace `GET /api/user/me` (o similar)  **con el JWT en el header** .
6. Según el rol recibido (por ejemplo `ADMIN`, `ANALYST`, etc.),  **redirige o muestra distinto contenido** .

##### Flujo completo: generación y validación de JWT en la API

##### ¿Qué es un JWT?

Un **JWT (JSON Web Token)** es un token compacto y seguro utilizado para transmitir información entre partes. Se compone de tres partes codificadas en Base64: HEADER.PAYLOAD.SIGNATURE

* **Header** : Tipo de token (`JWT`) y algoritmo de firma (ej. `HS256`).
* **Payload** : Contiene los  **claims** , como el nombre de usuario y roles.
* **Signature** : Garantiza la integridad del token (previene modificaciones).

##### Paso 1: Autenticación y generación del token

Ocurre en el método `loginUser(...)` de `UserDetailsServiceImp`

**1.1. El cliente envía un `POST` a `/api/auth/login` con su `username` y `password`. **

{

  "username": "centro8",
  "password": "1234"
}


**1.2. El sistema carga los datos del usuario desde la base de datos con `loadUserByUsername(username)`**

    UserSec userSec = userRepo.findUserEntityByUsername(username)

Se generan sus **roles y permisos** como una lista de `GrantedAuthority`, y se construye un `UserDetails` de Spring Security.


**1.3. Se verifica la contraseña (hasheada con BCrypt) y, si es correcta, se construye un objeto `Authentication`.**

    return new UsernamePasswordAuthenticationToken(username, userDetails.getPassword(), userDetails.getAuthorities());


**1.4. Se genera el JWT con `jwtUtils.createToken(authentication)`**

Este método genera el token utilizando:

* `authentication.getName()` → nombre de usuario
* `authentication.getAuthorities()` → roles y permisos
* Expiración definida
* Firma con clave secreta

    String accessToken = jwtUtils.createToken(authentication);


**1.5. El servidor responde al cliente con el JWT.**

{
  "username": "centro8",
  "message": "login ok",
  "token": "eyJhbGciOiJIUzI1NiIsInR...",
  "success": true
}


##### Paso 2: Envío del token en las siguientes peticiones

##### 2.1. El cliente almacena el token (usualmente en LocalStorage o sessionStorage) y lo envía en el header `Authorization` en cada request protegida:

    Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR...


##### Paso 3: Validación del token

Ocurre automáticamente antes de entrar al controlador protegido (`@RestController`) gracias a los filtros de Spring Security.


**3.1. El filtro (`JwtAuthenticationFilter`) intercepta el request**

Este filtro extrae el token del header `Authorization` y verifica su validez con `jwtUtils.validateToken(...)`.

    String username = jwtUtils.extractUsername(token);
	Claims claims = jwtUtils.extractAllClaims(token);

Realiza la validación de:

* Firma (contra la clave secreta)
* Integridad del contenido
* Fecha de expiración



**3.2. Si el token es válido, se construye un nuevo `UsernamePasswordAuthenticationToken` y se lo asigna al `SecurityContext`**

Esto permite que el usuario esté **autenticado dentro del contexto de Spring** y acceda a los endpoints protegidos según sus roles y permisos.


##### Seguridad y buenas prácticas

* El token se firma con una clave secreta que  **solo el backend conoce** .
* Nunca se guarda información sensible como contraseñas en el payload.
* Se recomienda usar HTTPS para proteger el token en tránsito.
* Los tokens tienen tiempo de expiración para reducir el riesgo en caso de robo.


##### Flujo como Secuencia

sequenceDiagram
    participant Cliente
    participant API
    participant BaseDeDatos
    Cliente->>API: POST /api/auth/login {username, password}
    API->>BaseDeDatos: Buscar usuario por username
    BaseDeDatos-->>API: Devuelve usuario (con roles y permisos)
    API->>API: Verifica contraseña
    API->>API: Genera JWT firmado
    API-->>Cliente: Devuelve token
    loop Cada petición futura
        Cliente->>API: GET /api/protegido (Header: Authorization: Bearer TOKEN)
        API->>API: Valida token (firma, expiración, claims)
        API->>BaseDeDatos: (Opcional) Carga detalles del usuario
        API-->>Cliente: Respuesta protegida
    end


##### Ventajas del Uso de JWT

* Stateless: no se necesita guardar sesiones del lado servidor.
* Escalable: útil para microservicios y APIs RESTful.
* Seguro: firmado digitalmente; se puede cifrar (opcional).
* Transportable: se envía en cada petición sin cookies.
