package progsegura.tif.tif.service.serviceGestionIncidentes;

import progsegura.tif.tif.entity.SecurityReporter;
import java.util.List;
import java.util.Optional;

public interface ISecurityReporterService {
    List<SecurityReporter> findAll();
    Optional<SecurityReporter> findById(Long id);
    SecurityReporter save(SecurityReporter sr);
    void deleteById(Long id);
    SecurityReporter update(SecurityReporter sr);
}