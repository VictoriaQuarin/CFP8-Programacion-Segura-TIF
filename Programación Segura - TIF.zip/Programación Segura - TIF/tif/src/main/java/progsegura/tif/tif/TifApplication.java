package progsegura.tif.tif;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TifApplication {

	public static void main(String[] args) {
		SpringApplication.run(TifApplication.class, args);
	}

}