package progsegura.tif.tif.service.serviceGestionIncidentes;

import progsegura.tif.tif.entity.Incident;
import java.util.List;
import java.util.Optional;

public interface IIncidentService {
    List<Incident> findAll();
    Optional<Incident> findById(Long id);
    Incident save(Incident incident);
    void deleteById(Long id);
    Incident update(Incident incident);
}